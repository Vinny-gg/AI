---
name: VS Code and containers
description: The user's preferred local development environment and containerization goal for this project.
---

The user develops this project in VS Code and wants a containerized run path.

**Why:** the user stated this while asking for the imported project to be fixed.

**How to apply:** keep local run/debug and Docker instructions aligned when changing how the CLI is built or started.
