package serpapi.example;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.Test;
import serpapi.SerpApi;
import serpapi.SerpApiException;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Scanner;

import static org.junit.Assert.*;

/** Offline CLI regressions; no real credentials or API calls. */
public class ChatAppTest {
    private static class FakeApi extends SerpApi {
        int calls;
        String question;
        final String response;

        FakeApi(String response) {
            this.response = response;
        }

        @Override
        public JsonObject search(Map<String, String> parameters) throws SerpApiException {
            calls++;
            question = parameters.get("q");
            if (response == null) {
                throw new SerpApiException("Request failed");
            }
            return JsonParser.parseString(response).getAsJsonObject();
        }
    }

    private String chat(String input, FakeApi client) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (Scanner scanner = new Scanner(input);
             PrintStream out = new PrintStream(output, true, StandardCharsets.UTF_8)) {
            App.run(scanner, out, client);
        }
        return output.toString(StandardCharsets.UTF_8);
    }

    @Test
    public void rejectsMissingBlankAndLiteralNullKeys() {
        assertFalse(App.isValidApiKey(null));
        assertFalse(App.isValidApiKey(" "));
        assertFalse(App.isValidApiKey("null"));
        assertTrue(App.isValidApiKey("test-key"));
    }

    @Test
    public void closedInputExitsWithoutCrashingOrSearching() {
        FakeApi client = new FakeApi("{}");
        assertTrue(chat("", client).contains("Goodbye!"));
        assertEquals(0, client.calls);
    }

    @Test
    public void blankInputAndExitDoNotSpendSearchCredits() {
        FakeApi client = new FakeApi("{}");
        String output = chat(" \n EXIT \nignored\n", client);
        assertTrue(output.contains("Please enter a question."));
        assertTrue(output.contains("Goodbye!"));
        assertEquals(0, client.calls);
    }

    @Test
    public void rendersNestedListsAndTextBlocks() {
        FakeApi client = new FakeApi("{\"text_blocks\":["
                + "{\"snippet\":\"Answer\",\"list\":[{\"snippet\":\"First\","
                + "\"list\":[{\"snippet\":\"Nested\"}]}]},"
                + "{\"text_blocks\":[{\"snippet\":\"More\"}]}]}");
        String output = chat("  question  \n", client);
        assertEquals("question", client.question);
        assertEquals(1, client.calls);
        assertTrue(output.contains("Answer"));
        assertTrue(output.contains("- First"));
        assertTrue(output.contains("- - Nested"));
        assertTrue(output.contains("More"));
    }

    @Test
    public void missingAndUnusableTextAreReportedWithoutCrashing() {
        assertTrue(chat("question\n", new FakeApi("{}"))
                .contains("No readable text response"));
        assertTrue(chat("question\n", new FakeApi(
                "{\"text_blocks\":[null,3,{\"snippet\":null},{\"snippet\":false}]}"))
                .contains("No readable text response"));
    }

    @Test
    public void apiFailureIsReportedAndChatCanContinue() {
        FakeApi client = new FakeApi(null);
        String output = chat("first\nsecond\nexit\n", client);
        assertEquals(2, client.calls);
        assertTrue(output.contains("SerpAPI error: Request failed"));
        assertTrue(output.contains("Goodbye!"));
    }
}
