package serpapi.example;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.Assert.*;

public class SerpApiConfigurationTest {
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void readsPlainAndQuotedKeysFromEnvFile() throws IOException {
        Path envFile = temporaryFolder.newFile(".env").toPath();
        Files.writeString(envFile, "# local secret\nOTHER=value\nSERPAPI_KEY=\"test-key\"\n",
                StandardCharsets.UTF_8);

        assertEquals("test-key", SerpApiConfiguration.apiKey(Map.of(), envFile));
    }

    @Test
    public void acceptsExportSyntaxAndSingleQuotes() throws IOException {
        Path envFile = temporaryFolder.newFile(".env").toPath();
        Files.writeString(envFile, "export SERPAPI_KEY='test-key'\n", StandardCharsets.UTF_8);

        assertEquals("test-key", SerpApiConfiguration.apiKey(Map.of(), envFile));
    }

    @Test
    public void environmentValueTakesPrecedenceOverEnvFile() throws IOException {
        Path envFile = temporaryFolder.newFile(".env").toPath();
        Files.writeString(envFile, "SERPAPI_KEY=file-key\n", StandardCharsets.UTF_8);

        assertEquals("environment-key",
                SerpApiConfiguration.apiKey(Map.of("SERPAPI_KEY", "environment-key"), envFile));
    }

    @Test
    public void returnsEnvironmentKeyWhenEnvFileDoesNotExist() {
        Path missingFile = temporaryFolder.getRoot().toPath().resolve("missing.env");

        assertEquals("environment-key",
                SerpApiConfiguration.apiKey(Map.of("SERPAPI_KEY", "environment-key"), missingFile));
        assertNull(SerpApiConfiguration.apiKey(Map.of(), missingFile));
    }

    @Test
    public void rejectsUnbalancedQuotesWithoutShowingTheKey() throws IOException {
        Path envFile = temporaryFolder.newFile(".env").toPath();
        Files.writeString(envFile, "SERPAPI_KEY=\"private-test-key\n", StandardCharsets.UTF_8);

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> SerpApiConfiguration.apiKey(Map.of(), envFile));
        assertTrue(error.getMessage().contains("line 1"));
        assertFalse(error.getMessage().contains("private-test-key"));
    }
}
