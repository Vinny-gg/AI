package serpapi.example;

import com.google.gson.JsonParser;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class SearchResponseFormatterTest {
    @Test
    public void formatsSnippetsListsAndNestedTextBlocks() {
        String json = """
                {"text_blocks":[
                  {"snippet":"Answer","list":[
                    {"snippet":"First","list":[{"snippet":"Nested"}]}
                  ]},
                  {"text_blocks":[{"snippet":"More"}]}
                ]}
                """;

        assertEquals("Answer\n- First\n- - Nested\nMore",
                SearchResponseFormatter.format(
                        JsonParser.parseString(json).getAsJsonObject().get("text_blocks")));
    }

    @Test
    public void safelyReturnsEmptyTextForMissingOrUnusableBlocks() {
        assertEquals("", SearchResponseFormatter.format(null));
        assertEquals("", SearchResponseFormatter.format(JsonParser.parseString("null")));
        assertEquals("", SearchResponseFormatter.format(JsonParser.parseString(
                "[null, 7, {\"snippet\":null}, {\"snippet\":\"  \"}]")));
    }
}
