package serpapi;

import org.junit.Test;
import serpapi.ParameterStringBuilder;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/***
 * Test converting map to URL query
 */
public class ParameterStringBuilderTest
{
  @Test
  public void getParamsString() throws Exception
  {
    Map<String, String> map = new HashMap<String, String>();
    map.put("output", "json");
    map.put("key", "value");

    assertEquals(ParameterStringBuilder.getParamsString(map),
        "output=json&key=value");
  }

  @Test
  public void optionalNullParametersAreOmitted() throws Exception {
    Map<String, String> parameters = new HashMap<>();
    parameters.put("location", null);
    parameters.put("q", "coffee & tea ☕");
    assertEquals("q=coffee+%26+tea+%E2%98%95",
        ParameterStringBuilder.getParamsString(parameters));
  }

  @Test
  public void emptyParametersProduceEmptyQuery() throws Exception {
    assertEquals("", ParameterStringBuilder.getParamsString(new HashMap<>()));
  }
}