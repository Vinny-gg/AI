package serpapi.example;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/** Resolves the API key from the process environment or a local, ignored .env file. */
final class SerpApiConfiguration {
    private SerpApiConfiguration() {
    }

    static String apiKey() {
        return apiKey(System.getenv(), Path.of(".env"));
    }

    static String apiKey(Map<String, String> environment, Path envFile) {
        String environmentKey = environment.get("SERPAPI_KEY");
        if (App.isValidApiKey(environmentKey)) {
            return environmentKey.strip();
        }
        if (!Files.exists(envFile)) {
            return environmentKey;
        }

        try {
            String fileKey = null;
            List<String> lines = Files.readAllLines(envFile, StandardCharsets.UTF_8);
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i).strip();
                if (i == 0 && line.startsWith("\uFEFF")) {
                    line = line.substring(1).stripLeading();
                }
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                if (line.startsWith("export ")) {
                    line = line.substring("export ".length()).stripLeading();
                }

                int equals = line.indexOf('=');
                if (equals < 0) {
                    throw new IllegalArgumentException(
                            "Invalid .env assignment on line " + (i + 1) + ".");
                }
                String name = line.substring(0, equals).strip();
                if (!"SERPAPI_KEY".equals(name)) {
                    continue;
                }

                String value = line.substring(equals + 1).strip();
                fileKey = unquote(value, i + 1);
            }
            return App.isValidApiKey(fileKey) ? fileKey : environmentKey;
        } catch (IOException e) {
            throw new IllegalStateException("Unable to read the local .env file.", e);
        }
    }

    private static String unquote(String value, int lineNumber) {
        if (value.length() >= 2) {
            char first = value.charAt(0);
            char last = value.charAt(value.length() - 1);
            if ((first == '"' && last == '"') || (first == '\'' && last == '\'')) {
                return value.substring(1, value.length() - 1);
            }
        }
        if (value.startsWith("\"") || value.startsWith("'")
                || value.endsWith("\"") || value.endsWith("'")) {
            throw new IllegalArgumentException(
                    "Unbalanced quotes for SERPAPI_KEY in .env on line " + lineNumber + ".");
        }
        return value;
    }
}
