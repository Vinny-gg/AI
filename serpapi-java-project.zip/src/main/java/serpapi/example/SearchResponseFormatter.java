package serpapi.example;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/** Converts Google AI Mode text blocks into readable console and Swing text. */
final class SearchResponseFormatter {
    private SearchResponseFormatter() {
    }

    static String format(JsonElement value) {
        StringBuilder output = new StringBuilder();
        appendBlocks(value, output, "");
        return output.toString().stripTrailing();
    }

    private static void appendBlocks(JsonElement value, StringBuilder output, String prefix) {
        if (value == null || !value.isJsonArray()) {
            return;
        }

        JsonArray blocks = value.getAsJsonArray();
        for (JsonElement element : blocks) {
            if (!element.isJsonObject()) {
                continue;
            }
            JsonObject block = element.getAsJsonObject();
            JsonElement snippet = block.get("snippet");
            if (snippet != null && snippet.isJsonPrimitive()
                    && snippet.getAsJsonPrimitive().isString()
                    && !snippet.getAsString().isBlank()) {
                output.append(prefix).append(snippet.getAsString()).append('\n');
            }

            appendBlocks(block.get("list"), output, prefix + "- ");
            appendBlocks(block.get("text_blocks"), output, prefix);
        }
    }
}
