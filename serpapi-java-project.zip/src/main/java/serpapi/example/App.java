package serpapi.example;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import serpapi.SerpApi;
import serpapi.SerpApiException;

/** Interactive Google AI Mode search client. Each question is a separate search. */
public class App {
    public static void main(String[] args) {
        String apiKey = SerpApiConfiguration.apiKey();
        if (!isValidApiKey(apiKey)) {
            System.err.println("Error: SERPAPI_KEY is not set. Set it in your environment before running.");
            System.exit(1);
            return;
        }

        Map<String, String> auth = new HashMap<>();
        auth.put("api_key", apiKey);
        auth.put("engine", "google_ai_mode");

        try (Scanner scanner = new Scanner(System.in)) {
            run(scanner, System.out, new SerpApi(auth));
        }
    }

    static boolean isValidApiKey(String apiKey) {
        return apiKey != null && !apiKey.isBlank() && !apiKey.equalsIgnoreCase("null");
    }

    static void run(Scanner scanner, PrintStream out, SerpApi client) {
        out.println("================================");
        out.println("       Welcome to AI Chat");
        out.println("================================");
        out.println("Ask a question and get an AI response.");
        out.println("Each question is an independent search, not a continuing conversation.");
        out.println("Type 'exit' to quit.");

        while (true) {
            out.print("\nYou: ");
            out.flush();
            // Closed stdin is normal for redirected input and non-interactive containers.
            if (!scanner.hasNextLine()) {
                break;
            }
            String question = scanner.nextLine().trim();
            if (question.equalsIgnoreCase("exit")) {
                break;
            }
            if (question.isEmpty()) {
                out.println("Please enter a question.");
                continue;
            }

            try {
                JsonObject results = client.search(Map.of("q", question));
                out.println("\nAI:");
                String response = SearchResponseFormatter.format(results.get("text_blocks"));
                if (response.isBlank()) {
                    out.println("No readable text response was found.");
                } else {
                    out.println(response);
                }
            } catch (SerpApiException e) {
                out.println("SerpAPI error: " + e.getMessage());
                if (Thread.currentThread().isInterrupted()) {
                    break;
                }
            }
        }
        out.println("\nGoodbye!");
    }

}
