package serpapi.example;

import com.google.gson.JsonObject;
import serpapi.SerpApi;
import serpapi.SerpApiException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

/** Desktop chat UI for independent Google AI Mode searches. */
public final class SwingChat {
    private static final Color NAVY = new Color(24, 48, 77);
    private static final Color MUTED = new Color(92, 107, 125);
    private static final Color PAGE = new Color(244, 247, 251);
    private static final Color WHITE = Color.WHITE;

    private final SerpApi client;
    private final JFrame frame = new JFrame("SerpApi AI Search");
    private final JTextPane transcript = new JTextPane();
    private final JTextField questionField = new JTextField();
    private final JButton sendButton = new JButton("Send");
    private final JLabel statusLabel = new JLabel("Ready");

    private SwingChat(SerpApi client) {
        this.client = client;
        buildWindow();
    }

    public static void main(String[] args) {
        String apiKey = SerpApiConfiguration.apiKey();
        if (!App.isValidApiKey(apiKey)) {
            if (!GraphicsEnvironment.isHeadless()) {
                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(
                        null,
                        "Set SERPAPI_KEY in your environment or local .env file, then restart the app.",
                        "SerpApi API key required",
                        JOptionPane.ERROR_MESSAGE));
            } else {
                System.err.println("Error: SERPAPI_KEY is not set.");
            }
            return;
        }

        Map<String, String> auth = new HashMap<>();
        auth.put("api_key", apiKey);
        auth.put("engine", "google_ai_mode");
        SwingUtilities.invokeLater(() -> {
            useSystemLookAndFeel();
            new SwingChat(new SerpApi(auth)).show();
        });
    }

    private void buildWindow() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(560, 460));
        frame.setSize(780, 640);
        frame.setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBackground(PAGE);
        root.setBorder(BorderFactory.createEmptyBorder(18, 20, 16, 20));

        JPanel header = new JPanel(new BorderLayout(0, 5));
        header.setBackground(PAGE);
        JLabel title = new JLabel("SerpApi AI Search");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 23));
        title.setForeground(NAVY);
        JLabel subtitle = new JLabel("Google AI Mode search · Each question is a separate search");
        subtitle.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        subtitle.setForeground(MUTED);
        header.add(title, BorderLayout.NORTH);
        header.add(subtitle, BorderLayout.SOUTH);
        root.add(header, BorderLayout.NORTH);

        transcript.setEditable(false);
        transcript.setFocusable(false);
        transcript.setBackground(WHITE);
        transcript.setForeground(NAVY);
        transcript.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        transcript.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        JScrollPane scrollPane = new JScrollPane(transcript);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(222, 229, 237)));
        scrollPane.getViewport().setBackground(WHITE);
        root.add(scrollPane, BorderLayout.CENTER);

        JPanel composer = new JPanel(new BorderLayout(10, 8));
        composer.setBackground(PAGE);
        questionField.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        questionField.setToolTipText("Type a question and press Enter");
        questionField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(205, 215, 226)),
                BorderFactory.createEmptyBorder(10, 11, 10, 11)));
        sendButton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        sendButton.setForeground(WHITE);
        sendButton.setBackground(NAVY);
        sendButton.setFocusPainted(false);
        sendButton.setBorder(BorderFactory.createEmptyBorder(9, 20, 9, 20));
        sendButton.addActionListener(event -> submitQuestion());
        questionField.addActionListener(event -> submitQuestion());

        JPanel inputRow = new JPanel(new BorderLayout(10, 0));
        inputRow.setBackground(PAGE);
        inputRow.add(questionField, BorderLayout.CENTER);
        inputRow.add(sendButton, BorderLayout.EAST);
        statusLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        statusLabel.setForeground(MUTED);
        composer.add(inputRow, BorderLayout.CENTER);
        composer.add(statusLabel, BorderLayout.SOUTH);
        root.add(composer, BorderLayout.SOUTH);

        frame.setContentPane(root);
        appendMessage("Welcome",
                "Ask a question below. Responses are independent searches, not a continuing conversation.",
                MUTED);
    }

    private void show() {
        frame.setVisible(true);
        questionField.requestFocusInWindow();
    }

    private void submitQuestion() {
        String question = questionField.getText().trim();
        if (question.isEmpty()) {
            statusLabel.setText("Type a question before sending.");
            questionField.requestFocusInWindow();
            return;
        }

        appendMessage("You", question, NAVY);
        questionField.setText("");
        setSearching(true);

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws SerpApiException {
                JsonObject results = client.search(Map.of("q", question));
                String response = SearchResponseFormatter.format(results.get("text_blocks"));
                return response.isBlank() ? "No readable text response was found." : response;
            }

            @Override
            protected void done() {
                try {
                    appendMessage("AI", get(), NAVY);
                    statusLabel.setText("Ready");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    statusLabel.setText("Search interrupted. You can try again.");
                    appendMessage("Error", "The search was interrupted. You can try again.", MUTED);
                } catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    String message = cause.getMessage();
                    if (message == null || message.isBlank()) {
                        message = "The search could not be completed.";
                    }
                    appendMessage("Search error", message, new Color(165, 46, 46));
                    statusLabel.setText("Search failed. You can try again.");
                } finally {
                    setSearching(false);
                }
            }
        }.execute();
    }

    private void setSearching(boolean searching) {
        questionField.setEnabled(!searching);
        sendButton.setEnabled(!searching);
        if (searching) {
            statusLabel.setText("Searching SerpApi…");
        } else {
            questionField.requestFocusInWindow();
        }
    }

    private void appendMessage(String heading, String body, Color headingColor) {
        StyledDocument document = transcript.getStyledDocument();
        SimpleAttributeSet headingStyle = new SimpleAttributeSet();
        StyleConstants.setBold(headingStyle, true);
        StyleConstants.setForeground(headingStyle, headingColor);
        StyleConstants.setFontFamily(headingStyle, Font.SANS_SERIF);
        StyleConstants.setFontSize(headingStyle, 14);
        StyleConstants.setSpaceAbove(headingStyle, 13);
        StyleConstants.setSpaceBelow(headingStyle, 3);

        SimpleAttributeSet bodyStyle = new SimpleAttributeSet();
        StyleConstants.setForeground(bodyStyle, NAVY);
        StyleConstants.setFontFamily(bodyStyle, Font.SANS_SERIF);
        StyleConstants.setFontSize(bodyStyle, 14);
        StyleConstants.setSpaceBelow(bodyStyle, 8);

        try {
            document.insertString(document.getLength(), heading + "\n", headingStyle);
            document.insertString(document.getLength(), body + "\n", bodyStyle);
            transcript.setCaretPosition(document.getLength());
        } catch (BadLocationException e) {
            throw new IllegalStateException("Could not update the chat transcript.", e);
        }
    }

    /** Apply the platform's standard Swing appearance when available. */
    public static void useSystemLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Swing's built-in look and feel remains a usable fallback.
        }
    }
}
