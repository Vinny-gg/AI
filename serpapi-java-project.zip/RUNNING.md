# Building and running

This repository is a Java 21 Gradle library with a terminal client and an
optional Swing desktop window. Open the repository root in VS Code and install the
[Extension Pack for Java](https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-pack).

## VS Code and Gradle

Create a local `.env` file from `.env.example` and set your key. Both the
VS Code launch configurations and the Java apps load that file automatically.
A `SERPAPI_KEY` already set in your environment takes precedence. Then use
**Run and Debug → SerpApi chat (Swing window)**. To use the original terminal
client, choose **Run and Debug → SerpApi chat (terminal)**. From a terminal,
start the desktop or terminal version:

```sh
./gradlew test
./gradlew runSwing
./gradlew run
```

The Swing window needs a desktop session and will not open inside a headless
container. Docker continues to use the terminal client. On Windows, use
`gradlew.bat` instead. Run the integration tests separately
only when you intend to make live SerpApi requests; they require `SERPAPI_KEY`
and can use account search credits:

```sh
./gradlew integrationTest
```

The default test task only runs offline tests and does not need an API key.

## Docker

Docker and Docker Compose must be installed. For Docker Compose, create an
ignored local `.env` file and put your key in it:

```sh
cp .env.example .env
# Edit .env and set SERPAPI_KEY to your own key.
docker compose run --build --rm chatbot
```

The interactive container exits when you type `exit` or send end-of-file.
Alternatively, build the image and pass the key without putting it in an image:

```sh
docker build -t serpapi-chat .
docker run --rm -it -e SERPAPI_KEY serpapi-chat
```

Never add your real `.env` file or API key to source control. The image builds
and runs its tests without an API key; only the running chat needs one.
